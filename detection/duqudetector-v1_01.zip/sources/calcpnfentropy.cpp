/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/

#include <math.h>
#include "common.h"


double CalcEntropy(unsigned char* buffer, DWORD size){
    
    double            H = 0.0;
    double          logBasePi;
    double                 pi;
    int freqs  [__WIN_SIZE__];
    int base   = __WIN_SIZE__;
            
    ZeroMemory(freqs, sizeof(int)*size);
    
    for (unsigned int i=0; i<size; i++){        
        freqs[buffer[i]] += 1;            
    }
    
    for (unsigned int i =0; i< size; i++){
            
        if (freqs[i]==0) {
            pi = 0.0;
            logBasePi = 0.0;
        }
        else {
            pi = static_cast<double>(freqs[i])/static_cast<double>(size);
            logBasePi = log10(pi) / log10(static_cast<double>(base)); 
        }
        H += (pi*logBasePi);
    }
        
    return H==0?H:-H;
}

int _tmain(int argc, TCHAR* argv[]){

    HANDLE               f, outf, pnfFindf;    
    DWORD                        bytesRead;
    WIN32_FIND_DATA        pnfFindFileData;    
    TCHAR            winDir[__INFO_SIZE__];
    TCHAR       winPNFFiles[__INFO_SIZE__];
    TCHAR        winPNFFile[__INFO_SIZE__];
    TCHAR           logFile[__INFO_SIZE__]  = {L"duqudetector_log.txt"};
    TCHAR         logMessage[__MSG_SIZE__];
    unsigned char  tmpbuffer[__WIN_SIZE__];
    unsigned char*                  buffer;
    double                        sumH = 0;
    double                               H;
    int                                num;
    int                              k = 0;
    
    if (argc == 2){
    
        ZeroMemory(logFile, __PATH_SIZE__);
        swprintf_s(logFile, __PATH_SIZE__, L"%s", argv[1]);            
    }
    else {
        printf("\nINFO: First argument [logfile] is missing, taking default values. \n\n");
    }    
    

    /* Create log file to store the results*/
    CreateLogFile(&outf, logFile);

    PutHeader(&outf, argv[0]);

    ZeroMemory(winPNFFile, __INFO_SIZE__);

    /* Retrieving Windows directory */ 
    if( !GetWindowsDirectory( winDir, __INFO_SIZE__ ) ){
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not retrieve windows directory. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);
    }

    /* Creating the %WINDIR%\inf\*.pnf string */    
    swprintf_s ( winPNFFiles
               , __INFO_SIZE__
               , L"%ls\\inf\\*.pnf"
               , winDir
               );

    /* Retrieving the first file satisfying the given filename expression */
    pnfFindf = FindFirstFile(winPNFFiles, &pnfFindFileData);
    if (pnfFindf == INVALID_HANDLE_VALUE) 
    {
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not get directory entry. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);
    } 
    else{
                
        do {
            wprintf (L"INFO: Checking file %s\n", pnfFindFileData.cFileName);            
            /* Creating string as winPNFFile = %WINDIR%\inf\[current].pnf*/    
            swprintf_s ( winPNFFile
                       , __INFO_SIZE__
                       , L"%ls\\inf\\%ls"
                       , winDir
                       , pnfFindFileData.cFileName
                       );        

            if ((f = CreateFile ( winPNFFile
                                , GENERIC_READ
                                , FILE_SHARE_READ
                                , NULL
                                , OPEN_EXISTING
                                , FILE_ATTRIBUTE_NORMAL
                                , NULL
                                )) == INVALID_HANDLE_VALUE) {
                    
                swprintf_s ( logMessage
                           , __MSG_SIZE__
                           , L"ERROR: %s - Could not open PNF file for reading. Error code: 0x%x\r\n"
                           , pnfFindFileData.cFileName
                           , GetLastError()
                           );
                PutOutToFile(outf, logMessage);
                wprintf(L"%s",logMessage);
            }
            /* File handle is valid*/
            else {
            
                sumH = 0;                
                k=0;
                num = 0;
                /* Allocating initial buffer with size __WIN_SIZE__ for the current sys file */
                buffer = (unsigned char*) realloc(NULL, sizeof(unsigned char)* __WIN_SIZE__);            
                
                /* Reading up the whole file into a buffer */
                do {
                    /* Reading the file into buffer in __CHUNK_SIZE__ chunks */                                                
                    if (ReadFile ( f
                                 , (LPVOID)tmpbuffer
                                 , (DWORD)__WIN_SIZE__
                                 , &bytesRead
                                 , NULL
                                 ) == FALSE){
                        swprintf_s ( logMessage
                                   , __MSG_SIZE__
                                   , L"ERROR: %s - Could not read the specified file. Error code: 0x%x\r\n"
                                   , pnfFindFileData.cFileName
                                   , GetLastError()
                                   );
                        PutOutToFile(outf, logMessage);
                        wprintf(L"%s",logMessage);
                    }
                    else{
                        H = CalcEntropy(tmpbuffer, bytesRead);
                        sumH += H;
                        k++;
                        if (SetFilePointer ( f
                                           , -(LONG)(__WIN_SIZE__/2) 
                                           , NULL 
                                           , FILE_CURRENT
                                           ) == INVALID_SET_FILE_POINTER){
                            wprintf ( L"ERROR: %s - Could not set file pointer. Error code: 0x%x\r\n"
                                    , pnfFindFileData.cFileName
                                    , GetLastError()
                                    );
                        }
                    
                    }                                
                } while(bytesRead == __WIN_SIZE__);                                    
                
                double avgH = sumH/static_cast<double>(k);
                if (avgH > __THRESHOLD__){                    
                    swprintf_s ( logMessage 
                               , __MSG_SIZE__
                               , L"SUSPICIOUS: The entropy of %ls is above threshold: %f\r\n"
                               , pnfFindFileData.cFileName
                               , avgH
                               ); 
                    PutOutToFile(outf, logMessage);
                    wprintf(L"%ls", logMessage);
                }
                                
                if (f){
                    CloseHandle(f);        
                }
                if(buffer){
                    free(buffer);
                    buffer = NULL;
                }                    
            }

        } while(FindNextFile(pnfFindf, &pnfFindFileData));
    }    
    if(pnfFindf) {
        FindClose(pnfFindf);
    }
    if (outf){
        CloseHandle(outf);
    }    
    
    return 0;    
}