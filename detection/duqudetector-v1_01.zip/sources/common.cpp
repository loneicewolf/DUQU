/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/
#include "common.h"

extern "C" void CreateLogFile(HANDLE* outf, LPCWSTR logFile){

    /* Open output file to store the results */
    if ((*outf = CreateFile ( logFile
                            , FILE_APPEND_DATA
                            , 0
                            , 0
                            , OPEN_ALWAYS
                            , FILE_ATTRIBUTE_NORMAL
                            , NULL
                            )) == INVALID_HANDLE_VALUE) {
        
        wprintf(L"ERROR: Could not create log file. Error code: 0x%x\n", GetLastError());
        exit(1);
    }
}


/* Putting out the hex dump */
extern "C" void PutOut(unsigned char* buffer, int patternLength){
    
    int i=0;
    if (buffer[i] == '^') i++;
    for (i; i< patternLength; i++){        
        if (i % 8) 
            printf("%02x ", buffer[i]);
        else
            printf("\n%02x ", buffer[i]);
    }    
    printf("\n");
}

extern "C" void PutOutToFile(HANDLE outf, wchar_t* logMessage){
    
    DWORD  bytesWritten;    

    if (WriteFile ( outf 
                  , logMessage
                  , wcslen(logMessage)*sizeof(wchar_t)
                  , &bytesWritten
                  , NULL
                  ) == FALSE){
                            
        wprintf(L"ERROR: Could not write into log file. Error code: 0x%x\n", GetLastError());
    } 
}

extern "C" void PutHeader(HANDLE* outf, TCHAR* fileName){

    TCHAR      logMessage [__MSG_SIZE__];
    SYSTEMTIME                        st;      
    
    GetSystemTime(&st);
    
    swprintf_s ( logMessage
               , __MSG_SIZE__
               , L"\r\n%s is started at %02d/%02d/%d %02d:%02d\r\n"
               , fileName
               , st.wMonth
               , st.wDay               
               , st.wYear
               , st.wHour
               , st.wMinute);        

    PutOutToFile(*outf, logMessage);

}


extern "C" int GetCurrentFile(HANDLE* f, TCHAR* currFile){

    int    ret = 1;    
    
    /* Opening the next file for matching patterns */
    if ((*f = CreateFile ( currFile
                         , GENERIC_READ
                         , FILE_SHARE_READ
                         , NULL
                         , OPEN_EXISTING
                         , FILE_ATTRIBUTE_NORMAL
                         , NULL
                         )) == INVALID_HANDLE_VALUE) {
    
        wprintf(L"ERROR: Could not read the specified file. Error code: 0x%x\n", GetLastError());
        ret = 0;
    
    }
    return ret;
}
