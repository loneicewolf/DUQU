/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <locale.h>

#ifdef _WIN32_WINNT
#undef _WIN32_WINNT
#endif
#define _WIN32_WINNT 0x0501

#ifdef NTDDI_VERSION
#undef NTDDI_VERSION
#endif
#define NTDDI_VERSION 0x05010000

#define         __MSG_SIZE__ 512
#define       __INFO_SIZE__ 4192
#define        __PATH_SIZE__ 512
#define        __PATT_SIZE__ 128
#define     __CHUNK_SIZE__ 65536
#define        __WIN_SIZE__  256
#define   __MAX_BIN_PATTERN__ 10

const double __THRESHOLD__ = 0.6;

#ifdef __cplusplus
extern "C" {
#endif 

void CreateLogFile(HANDLE* outf, LPCWSTR logFile);
void PutOut(unsigned char* buffer, int patternLength);
void PutOutToFile(HANDLE outf, wchar_t* logMessage);
void PutHeader(HANDLE* outf, TCHAR* fileName);
int  GetCurrentFile(HANDLE* f, TCHAR* currFile);

#ifdef __cplusplus
}
#endif 


