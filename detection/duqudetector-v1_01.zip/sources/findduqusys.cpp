/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/


#include "common.h"


TCHAR                   logMessage [__MSG_SIZE__]; 
HANDLE                                       outf;     

typedef struct _XBINPATTERN {
    wchar_t                  name [__PATT_SIZE__];
    unsigned char         pattern [__PATT_SIZE__];    
    unsigned int                           length;
}   XBINPATTERN;

XBINPATTERN patternAttrs[] = {
    /* Pattern name*/  /*Pattern*/           /* Size */    
    {L"decrypt magic1", {0xb8, 0xa3, 0x6d, 0x2d  , 
                         0x1e                  } , 5  },
    {L"decrypt magic2", {0x56, 0x81, 0xf1, 0x22  ,
                         0x11, 0x47, 0x08      } , 7  },
    {L"unknown magic" , {0x44, 0x24, 0x10, 0x50  , 
                         0x51, 0x55, 0x6a, 0x02  , 
                         0x53                  } , 9  },
    {L"imul magic1"   , {0x69, 0xc0, 0x93, 0x72  , 
                         0x74, 0x04            } , 6  },
    {L"B3 1F xor"     , {0x57, 0xB9, 0x1F, 0xB3  , 
                         0x1F, 0xB3, 0xEB, 0x0D} , 8  },
    {L"30 76 60"      , {0x30, 0x76, 0x60, 0x8D  , 
                         0x49, 0x00, 0x8B, 0x54  , 
                         0x24, 0x44, 0x8D, 0x1C  , 
                         0x16, 0x83, 0xC6, 0x0C }, 16 },
    {L"89 74 24"      , {0x89, 0x74, 0x24, 0x4C  ,
                         0x8D, 0x74, 0x24, 0x3C  , 
                         0x8D, 0x44, 0x24, 0x44  ,
                         0xE8, 0x75, 0xFE, 0xFF }, 16 }, 
    {L"FF 8D 74"      , {0xFF, 0x8D, 0x74, 0x24  ,
                         0x2C, 0x8D, 0x44, 0x24  , 
                         0x44, 0xE8, 0x68, 0xFE  ,
                         0xFF, 0xFF, 0x8B, 0x74 }, 16 },                             
    {L"83 FE 07"      , {0x83, 0xFE, 0x07, 0x7E  , 
                         0xD6, 0xEB, 0x03, 0x83  , 
                         0xC6, 0x01, 0x83, 0xEE  ,
                         0x02, 0x78, 0x13, 0x8B }, 16 },                             
    {L"1D C4 33"      , {0x1D, 0xC4, 0x33, 0x01  , 
                         0x00, 0x90, 0x8B, 0x54  , 
                         0xB4, 0x38, 0x52, 0xFF  , 
                         0xD3, 0x83, 0xEE, 0x01} , 16 },
    {L"79 F4 8B"      , {0x79, 0xF4, 0x8B, 0xC7  , 
                         0x5F, 0x5E, 0x5D, 0x5B , 
                         0x83, 0xC4, 0x4C, 0xC3  , 
                         0xCC, 0xCC, 0xCC, 0xCC }, 16 }
};

int patternAttrsNumOfItems = sizeof(patternAttrs) / sizeof(XBINPATTERN);

/* Check the current buffer if it matches */
int CheckCurrentPattern(unsigned char* buffer, XBINPATTERN patternAttr){
    
    unsigned int j=0;
        
    /* Count the number of matching bytes */        
    while(j<patternAttr.length && buffer[j] == patternAttr.pattern[j]){
        j++;
    }
    
    /* Check if all the bytes are matching */
    if(j==patternAttr.length){
        wprintf(L"SUSPICIOUS: Pattern %ls is matching: ", patternAttr.name);
        PutOut((unsigned char*)patternAttr.pattern, patternAttr.length);
        return 1;
    }
        
    return 0;            
}

int FileIntoBuf(TCHAR* filename, HANDLE f, unsigned char** buffer, DWORD* bytesRead){
    
    unsigned char tmpbuffer[__CHUNK_SIZE__];            
    int                             num = 0;
    
    ZeroMemory(tmpbuffer, __CHUNK_SIZE__);
                        
    /* Reading up the whole file into a buffer */
    do {
        /* Reading the file into buffer in __CHUNK_SIZE__ chunks */                                                
        if (ReadFile ( f 
                     , (LPVOID)tmpbuffer
                     , (DWORD)__CHUNK_SIZE__
                     , bytesRead
                     , NULL
                     ) == FALSE){
            
            swprintf_s ( logMessage
                       , __MSG_SIZE__
                       , L"ERROR: Could not open file for reading. Error code: 0x%x\r\n"
                       , GetLastError()
                       );
            PutOutToFile(outf, logMessage);
            wprintf(L"%s",logMessage);
            return 0;
        }
        
        if (num) *buffer = (unsigned char*) realloc(*buffer, __CHUNK_SIZE__*(num)+(*bytesRead));    
        
        memcpy_s ( *buffer+(num)*__CHUNK_SIZE__
                 , __CHUNK_SIZE__
                 , tmpbuffer
                 , *bytesRead
                 );
        (num)++;
    } while((*bytesRead) == __CHUNK_SIZE__);                                    
                            
    /* The length of the buffer is returned */
    return num;
}

BOOL Is64BitOS()
{
   BOOL is64BitOS = FALSE;

   // We check if the OS is 64 Bit
   typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL); 

   LPFN_ISWOW64PROCESS
      fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(
      GetModuleHandleW(L"kernel32"),"IsWow64Process");
 
   if (NULL != fnIsWow64Process)
   {
      if (!fnIsWow64Process(GetCurrentProcess(),&is64BitOS))
      {
         //error
      }
   }
   return is64BitOS;
}

int _tmain(int argc, _TCHAR* argv[]){

    HANDLE                           f, findf;
    DWORD                           bytesRead;    
    WIN32_FIND_DATA              findFileData;                
    TCHAR           systemDir [__INFO_SIZE__] = {L"c:\\WINDOWS\\system32"};
    TCHAR            sysFiles [__INFO_SIZE__];
    TCHAR         currSysFile [__INFO_SIZE__];
    TCHAR             logFile [__PATH_SIZE__] = {L"duqudetector_log.txt"};
    unsigned char*              buffer = NULL;
    int                                bufLen;
    bool                              noMatch;
    register int                      num = 0;

    if (argc == 2){
    
        ZeroMemory(logFile, __PATH_SIZE__);
        swprintf_s(logFile, __PATH_SIZE__, L"%s", argv[1]);            
    }
    else {
        printf("\nINFO: First argument [logfile] is missing, taking default values. \n\n");
    }    
        
    /* Create log file to store the results*/
    CreateLogFile(&outf, logFile);

    PutHeader(&outf, argv[0]);          
    
    
    /* Getting system dir to search for sys files. Note: There is no '\' at the end of the line */
    if (!GetSystemDirectory(systemDir, __INFO_SIZE__ )){
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not retrieve system directory. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);        
    }
    
    if (Is64BitOS()){
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"WARNING: 64-bit system is detected. Some drivers may remain unchecked. %ls"
                   , L"Note that Duqu currently does not use 64-bit kernel drivers!\r\n"
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);                 
    }    
    
    /* Creating the %SystemRoot%\system32\drivers\*.sys string */    
    swprintf_s ( sysFiles
               , __INFO_SIZE__
               , L"%ls\\drivers\\*.sys"
               , systemDir
               );
    
    /* Retrieving the firt file satisfying the given filename expression */
    findf = FindFirstFile(sysFiles, &findFileData);
    if (findf == INVALID_HANDLE_VALUE) 
    {
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not find the specified file. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);     
    }
    else {
    
        /* Iterating through all the .sys files in the %SystemRoot%\system32\drivers\ directory */
        do {            
            
            /* Creating the full path for the found sys file */
            swprintf_s ( currSysFile
                       , __INFO_SIZE__
                       , L"%ls\\drivers\\%ls"
                       , systemDir
                       , findFileData.cFileName 
                       );
            
            if (GetCurrentFile(&f, currSysFile)){        
                
                wprintf (L"INFO: Checking file %ls\n", findFileData.cFileName);           
    
                /* Allocating initial buffer with size __CHUNK_SIZE__ for the current sys file */
                buffer = (unsigned char*) realloc(NULL, sizeof(unsigned char)* __CHUNK_SIZE__);            
                
                /* Retrieving the length of the buffer in bufLen */
                num  = FileIntoBuf ( findFileData.cFileName
                                   , f
                                   , &buffer
                                   , &bytesRead
                                   );
                bufLen = (((num)-1)*__CHUNK_SIZE__ + (bytesRead));            
                if (bufLen){

                    /* Matching the current buffer against all the patterns */                
                    for (int i=0; i<patternAttrsNumOfItems; i++){
                        noMatch = true;
                        /* The number of bytes read from the file should be at 
                           least equal to the number of bytes of the current pattern */                
                        if (bytesRead >= patternAttrs[i].length ){
                            unsigned j = 0;
                            while (noMatch && j < bufLen-patternAttrs[i].length+1){
                                j++;
                                if (CheckCurrentPattern(buffer+j, patternAttrs[i])){
                                                        
                                    swprintf_s ( logMessage
                                               , __MSG_SIZE__
                                               , L"SUSPICIOUS: File %ls matches pattern called %ls\r\n"
                                               , findFileData.cFileName
                                               , patternAttrs[i].name
                                               );
                                                            
                                    PutOutToFile(outf, logMessage);
                                    noMatch = false;
                                } // end of if
                            } // end of inner for        
                        }  // end of bytesRead if
                        else if (num == 1){
                            wprintf ( L"\nINFO: Skipping current pattern \"%ls\" [buffer length < pattern length]\n"
                                    , patternAttrs[i].name
                                    );
                        }
                    } // end of outer for
                } // end of bufLen if                        
                if (f){
                    CloseHandle(f);        
                }
                if(buffer){
                    free(buffer);            
                    buffer = NULL;
                }                
                _flushall();
            }
        } while(FindNextFile(findf, &findFileData));
        
        if(findf) {
            FindClose(findf);
        }
    }                    
    return 0;
}