/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/
#include "common.h"

TCHAR                            logMessage [__MSG_SIZE__];   
HANDLE                                                outf;

typedef struct _XBINPATTERN {
    wchar_t                           name [__PATT_SIZE__];
    unsigned char                  pattern [__PATT_SIZE__];    
    unsigned int                                    length;
}   XBINPATTERN;

typedef struct _XFILEPATTERN{
    wchar_t                        filename[__PATT_SIZE__];
    XBINPATTERN   filebinpatternAttrs[__MAX_BIN_PATTERN__];
    int                                             length;
    int                                           matchsum;
}   XFILEPATTERN;


XFILEPATTERN filepatternAttrs[] = {
    /* file name        {pattern name / pattern / length } length / matchsum */
    {L"~DN1.tmp",   {
                        {L"Exists",        {'*'                         }, 1}
                    }                                                 , 1, 0},
    {L"~DQ*",       { 
                        {L"~DQ beginning", {'^', 0xad, 0x34, 0x00       }, 4}, 
                        {L"AEh91AY",       {     0x41, 0x45, 0x68, 0x39,  
                                                 0x31, 0x41, 0x59       }, 7} 
                    }                                                 , 2, 0},
    {L"~DF*",       { 
                        {L"~DF beginning", {'^', 0x41, 0x42, 0x68, 0x39, 
                                                 0x31, 0x41, 0x59, 0x26, 
                                                 0x53, 0x59            }, 13}
                    }                                                 , 1, 0}
};
 
int filepatternAttrsNumOfItems = sizeof(filepatternAttrs) / sizeof(_XFILEPATTERN);

int FileIntoBuf(TCHAR* filename, HANDLE f, unsigned char** buffer, DWORD* bytesRead){
            
    
    SetFilePointer ( f
                   , 0
                   , 0
                   , FILE_BEGIN
                   );
    

    /* Reading the first __CHUNK_SIZE__ byte from the file */        
    if (ReadFile ( f 
                 , (LPVOID)(*buffer)
                 , (DWORD)__CHUNK_SIZE__
                 , bytesRead
                 , NULL 
                 ) == FALSE ){
        
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: %s - Could not open file for reading. Error code: 0x%x\r\n"
                   , filename
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);
        return 0;
    }
                            
    /* The length of the buffer is returned */
    return (*bytesRead);
}


/* Check the current buffer if it matches */
int CheckCurrentPattern(unsigned char* buffer, XBINPATTERN patternAttr){
    
    unsigned int j = 0;
    unsigned int i = 0;
    /* if matching of file begining is required */
    if (patternAttr.pattern[0]=='^'){
        j++;
    }

    /* Count the number of matching bytes */        
    while(j<patternAttr.length && buffer[i] == patternAttr.pattern[j]){
        j++;
        i++;
    }
    
    /* Check if all the bytes are matching */
    if(j==patternAttr.length){
        return 1;
    }
        
    return 0;            
}

int MatchPattern(TCHAR* filename, XBINPATTERN currPattern, HANDLE f, HANDLE outf){

    TCHAR           logMessage [__MSG_SIZE__];    
    int                               ret = 0;
    unsigned char*              buffer = NULL;
    int                                bufLen;    
    DWORD                           bytesRead;    
    
    /* Allocating initial buffer with size __CHUNK_SIZE__ for the current tmp file */
    buffer = (unsigned char*) realloc(NULL, sizeof(unsigned char)* __CHUNK_SIZE__);                        
                    
    /* Retrieving the length of the buffer in bufLen */
    if (bufLen = FileIntoBuf(filename, f, &buffer, &bytesRead)){

                    
        /* The number of bytes read from the file should be at least equal to the number of bytes of the current pattern*/
        if (bytesRead >= currPattern.length){

            /*  Iterating through the bytes read from a file */                
            unsigned int j=0;
            while (!ret && j < bufLen-currPattern.length+1){        
                                                                  
                /* Checking if there is a restriction on the match to the begining of the file */
                bool fileStartCheck = currPattern.pattern[0] == '^';
                int isMatch = CheckCurrentPattern(buffer+j, currPattern);              
                if ( (currPattern.pattern[0] == '*')
                ||   (fileStartCheck && (j==0) && isMatch)
                ||   (!fileStartCheck && isMatch) ){
                    
                    swprintf_s ( logMessage 
                               , __MSG_SIZE__
                               , L"SUSPICIOUS: File %ls matches pattern %ls\r\n"
                               , filename
                               , currPattern.name
                               );
                    
                    wprintf(L"%ls --> ", logMessage);
                    PutOut(currPattern.pattern, currPattern.length);
                    PutOutToFile(outf, logMessage);

                    ret = 1;
                } // end of if
				j++;  
            } // end of while 
        } // end of bytesRead if
        else {
            wprintf(L"INFO: Skipping current pattern \"%ls\" [buffer length < pattern length]\n", 
                    currPattern.name);                                                    
        }                            
    }
    if(buffer){
        free(buffer);                    
    }
    return ret;
}


int _tmain(int argc, _TCHAR* argv[]){

    HANDLE                     f,  findf;            
    WIN32_FIND_DATA              findFileData;            
    TCHAR             tempDir [__INFO_SIZE__];
    TCHAR           tempFiles [__INFO_SIZE__];        
    TCHAR             logFile [__PATH_SIZE__] = {L"duqudetector_log.txt"};
    TCHAR        currTempFile [__INFO_SIZE__];
    
    
    if (argc == 2){
    
        ZeroMemory(logFile, __PATH_SIZE__);
        swprintf_s(logFile, __PATH_SIZE__, L"%s", argv[1]);            
    }
    else {
        printf("\nINFO: First argument [logfile] is missing, taking default values. \n\n");
    }    
    
    
    /* Create log file to store the results*/
    CreateLogFile(&outf, logFile);

    PutHeader(&outf, argv[0]);
    
    /* Getting current temp dir to search for temp files. Note: There is no '\' at the end of the line */
    if (!GetTempPath((DWORD)__INFO_SIZE__, tempDir)){
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not retrieve %TEMP% directory. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);
    }
    
    /* Iterating through all the files that match the patterns defined along the filepatternAttr array elements*/    
    for (int i=0; i<filepatternAttrsNumOfItems; i++){

        /* Creating the %TEMP%\[Duqu temporary files] string */    
        swprintf_s ( tempFiles
                   , __INFO_SIZE__
                   , L"%s\\%s"
                   , tempDir
                   , filepatternAttrs[i].filename
                   );
        
        /* Retrieving the firt file satisfying the given filename expression */
        findf = FindFirstFile(tempFiles, &findFileData);
        if (findf == INVALID_HANDLE_VALUE) 
        {
            swprintf_s ( logMessage
                       , __MSG_SIZE__
                       , L"INFO: Could not find any file for pattern %s. Error code: 0x%x\r\n"
                       , filepatternAttrs[i].filename
                       , GetLastError()
                       );
            //PutOutToFile(outf, logMessage);
            wprintf(L"%s",logMessage);
        } 
        else {    
        
            
            /* Iterating through the duqu temp files matching the filename regexp in the %TEMP% directory */
            do {

                /* Creating the full path for the found tmp file */    
                swprintf_s ( currTempFile
                           , __INFO_SIZE__
                           , L"%ls\\%ls"
                           , tempDir
                           , findFileData.cFileName 
                           );

                if (GetCurrentFile(&f, currTempFile)){    
                    
                    /* File handle is valied*/                
                    wprintf (L"INFO: Checking file %ls\n", findFileData.cFileName);           
                    
                    /* Iterating through all the patterns defined for a file */
                    for (int o=0; o < filepatternAttrs[i].length; o++){                            
                            
                        XBINPATTERN currPattern = filepatternAttrs[i].filebinpatternAttrs[o];
                        if (MatchPattern ( findFileData.cFileName
                                         , currPattern
                                         , f
                                         , outf
                                         )) {
                            filepatternAttrs[i].matchsum++;
                        }
                    }                     
                    /* Check if all the patterns defined for a file are mathcing */
                    if(filepatternAttrs[i].matchsum == filepatternAttrs[i].length) {
                        swprintf_s ( logMessage
                                   , __MSG_SIZE__
                                   , L"SUSPICIOUS: File %ls matches all the defined patterns\r\n"
                                   , findFileData.cFileName
                                   );                                                
                        PutOutToFile(outf, logMessage);
						filepatternAttrs[i].matchsum=0;
                    }            

                    if (f){
                        CloseHandle(f);        
                    }
                    _flushall();
                }
                else{
                    swprintf_s ( logMessage
                               , __MSG_SIZE__
                               , L"WARNING: Could not read file %s. This might be normal (e.g. open file).\r\n"
                               , findFileData.cFileName
                               );                                                
                    PutOutToFile(outf, logMessage);
                }
            } while(FindNextFile(findf, &findFileData));
                
            if(findf) {
                FindClose(findf);
            }
        } // end of FirstFile INVALID_HANDLE_VALUE if
    } // end of filepattern finder for. 
                    
    if (outf)
        CloseHandle(outf);

    return 0;
}