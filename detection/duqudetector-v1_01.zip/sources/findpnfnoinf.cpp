/* Copyright Laboratory Of Cryptography and System Security - CrySyS, Gabor Pek
   Budapest University of Technology and Economics
   http://www.crysys.hu/
*/
#include "common.h"


int _tmain(int argc, _TCHAR* argv[]){
    
    HANDLE           outf, pnfFindf, infFindf;
    WIN32_FIND_DATA           pnfFindFileData;
    WIN32_FIND_DATA           infFindFileData;
    TCHAR              logFile[__PATH_SIZE__] = {L"duqudetector_log.txt"};
    TCHAR               winDir[__INFO_SIZE__];
    TCHAR          winPNFFiles[__INFO_SIZE__];
    TCHAR           winINFFile[__INFO_SIZE__];
    TCHAR           winPNFFile[__INFO_SIZE__];    
    wchar_t          logMessage[__MSG_SIZE__];            
    TCHAR*                 infFileName = NULL;
    wchar_t                   *context = NULL;
                
    if (argc == 2){
    
        ZeroMemory(logFile, __PATH_SIZE__);
        swprintf_s(logFile, __PATH_SIZE__, L"%s", argv[1]);            
    }
    else {
        printf("\nINFO: First argument [logfile] is missing, taking default values. \n\n");
    }    
    
    
    /* Create log file to store the results*/
    CreateLogFile(&outf, logFile);

    PutHeader(&outf, argv[0]);    
    
    ZeroMemory(winPNFFile, __INFO_SIZE__);
    
    /* Retrieving Windows directory */ 
    if( !GetWindowsDirectory( winDir, __INFO_SIZE__ ) ){
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not retrieve windows directory. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);
    }

    /* Creating the %WINDIR%\inf\*.pnf string */    
    swprintf_s ( winPNFFiles
               , __INFO_SIZE__
               , L"%ls\\inf\\*.pnf"
               , winDir
               );

    /* Retrieving the first file satisfying the given filename expression */
    pnfFindf = FindFirstFile(winPNFFiles, &pnfFindFileData);
    if (pnfFindf == INVALID_HANDLE_VALUE) 
    {
        swprintf_s ( logMessage
                   , __MSG_SIZE__
                   , L"ERROR: Could not get directory list. Error code: 0x%x\r\n"
                   , GetLastError()
                   );
        PutOutToFile(outf, logMessage);
        wprintf(L"%s",logMessage);                
    } 
    else {
        /* searching PNF file with no corresponding INF file*/
        do {
            
                /* Creating string as winPNFFile = %WINDIR%\inf\[current].pnf*/
            swprintf_s ( winPNFFile
                       , __INFO_SIZE__
                       , L"%ls\\inf\\%ls"
                       , winDir
                       , pnfFindFileData.cFileName
                       );

            /* Creating the corresponding inf file string with path */
            infFileName = wcstok_s ( winPNFFile
                                   , L"."
                                   , &context
                                   );        
            
            /* Creating the %WINDOWS%\inf\*.inf string */    
            swprintf_s ( winINFFile
                       , __INFO_SIZE__
                       , L"%ls.inf"
                       , infFileName
                       );
            
            /* Identifying the first inf file for the corresponding pnf file */
            infFindf = FindFirstFile(winINFFile, &infFindFileData);
            if (infFindf == INVALID_HANDLE_VALUE)
            {                
                swprintf_s ( logMessage
                           , __MSG_SIZE__
                           , L"SUSPICIOUS: There is no corresponding inf file for %ls\r\n"
                           , winPNFFile
                           );                                            
                
                wprintf(L"%ls", logMessage);        
                PutOutToFile(outf, logMessage);            
            }
            wprintf(L"INFO: Checking file %ls\n", winPNFFile);
        } while(FindNextFile(pnfFindf, &pnfFindFileData));
        
        
        if(pnfFindf) {
            FindClose(pnfFindf);
        }
    }
    if(outf)
        CloseHandle(outf);

    return 0;
}